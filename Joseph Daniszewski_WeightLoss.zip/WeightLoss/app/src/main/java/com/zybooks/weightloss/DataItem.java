package com.zybooks.weightloss;

public class DataItem {
    private String text;

    public DataItem(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }
}
