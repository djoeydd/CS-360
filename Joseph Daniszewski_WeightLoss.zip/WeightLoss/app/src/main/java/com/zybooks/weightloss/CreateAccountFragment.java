package com.zybooks.weightloss;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.annotation.NonNull;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class CreateAccountFragment extends Fragment {
    private EditText usernameEditText;
    private EditText emailEditText;
    private EditText passwordEditText;
    private EditText confirmPasswordEditText;
    private Button signUp;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.fragment_create_account, container, false);
        usernameEditText = rootview.findViewById(R.id.emailEditText);
        emailEditText = rootview.findViewById(R.id.usernameEditText);
        passwordEditText = rootview.findViewById(R.id.passwordEditText);
        confirmPasswordEditText = rootview.findViewById(R.id.confirmPasswordEditText);
        signUp = rootview.findViewById(R.id.confirm_create_button);

        signUp.setEnabled(false);

        addTextWatcher(usernameEditText);
        addTextWatcher(emailEditText);
        addTextWatcher(passwordEditText);
        addTextWatcher(confirmPasswordEditText);


        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle login button click
                createAccount();
            }
        });
        return rootview;
    }

    private void addTextWatcher(EditText editText) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                checkFieldsAndEnableButton();
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });
    }

    private void checkFieldsAndEnableButton() {
        String email = emailEditText.getText().toString();
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        String confirmPassword = confirmPasswordEditText.getText().toString();

        signUp.setEnabled(!email.isEmpty() && !username.isEmpty() && !password.isEmpty() && !confirmPassword.isEmpty());
    }

    private void createAccount() {

        String email = emailEditText.getText().toString();
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        String confirmPassword = confirmPasswordEditText.getText().toString();

        MainActivity.setisLoggedin(true);
        //eventually check database to determine email and username eligibility
        if (!password.equals(confirmPassword)){
            Toast.makeText(getContext(),"Passwords do not match", Toast.LENGTH_SHORT).show();
        }
        else {
            Intent intent = new Intent(getContext(), DataDisplayActivity.class);
            startActivity(intent);
        }

    }
}
