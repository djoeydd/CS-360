package com.zybooks.weightloss;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity implements DataAdapter.OnDeleteButtonClickListener {

    private RecyclerView dataRecyclerView;
    private DataAdapter dataAdapter;
    private static int currentWeight;
    private static int targetWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_display_screen);

        dataRecyclerView = findViewById(R.id.dataRecyclerView);

        // Set up RecyclerView
        dataAdapter = new DataAdapter(getDummyData(), this);
        dataRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        dataRecyclerView.setAdapter(dataAdapter);

        // Set TextView text
        TextView currentWeightText = findViewById(R.id.current_weight_number);
        currentWeightText.setText(getCurrentWeight());

        TextView targetWeightText = findViewById(R.id.target_weight_number);
        targetWeightText.setText(getTargetWeight());
    }

    // Function to populate page (database will eventually retrieve)
    private List<DataItem> getDummyData() {
        List<DataItem> dummyData = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            dummyData.add(new DataItem("Weight " + i));
        }
        return dummyData;
    }

    private String getCurrentWeight() {
        // Database will eventually get the weight
        currentWeight = 180; // Number for testing
        return String.valueOf(currentWeight);
    }

    private String getTargetWeight() {
        // Database will eventually get the weight
        targetWeight = 160; // Number for testing
        return String.valueOf(targetWeight);
    }

    public static boolean goalReached() {
        // Set numbers for testing; database will eventually get the weight
        currentWeight = 150;
        targetWeight = 160;

        return currentWeight <= targetWeight;
    }

    @Override
    public void onDeleteButtonClick(DataItem item) {
        // delete item from RecyclerView
        dataAdapter.getData().remove(item);
        dataAdapter.notifyDataSetChanged();
    }
}

