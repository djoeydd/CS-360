package com.zybooks.weightloss;

import static java.util.logging.Logger.global;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import java.util.logging.Logger;

public class MainActivity extends AppCompatActivity {
    static boolean loggedIn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!isLoggedIn()) {
            startLoginActivity();
        } else {
            if (DataDisplayActivity.goalReached()) {
                Intent intent = new Intent(this, CongratulationsActivity.class);
                startActivity(intent);
                finish();
            }
            else {
                startDataDisplayActivity();
            }
        }
    
    }

    public static void setisLoggedin(boolean login){
        loggedIn = login;
    }
    private boolean isLoggedIn() {
        return loggedIn;
    }

    private void startLoginActivity() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
    private void startDataDisplayActivity() {
        // Start the DataDisplayActivity
        Intent intent = new Intent(this, DataDisplayActivity.class);
        startActivity(intent);
        finish();
    }
}
