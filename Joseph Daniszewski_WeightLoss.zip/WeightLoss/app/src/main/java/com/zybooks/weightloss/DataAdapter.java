package com.zybooks.weightloss;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.weightloss.DataItem;
import com.zybooks.weightloss.R;

import java.util.List;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {

    private List<DataItem> data;
    private OnDeleteButtonClickListener onDeleteButtonClickListener;

    public DataAdapter(List<DataItem> data, OnDeleteButtonClickListener listener) {
        this.data = data;
        this.onDeleteButtonClickListener = listener;
    }

    public interface OnDeleteButtonClickListener {
        void onDeleteButtonClick(DataItem item);
    }

    public List<DataItem> getData() {
        return data;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textView;
        public Button deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.weightTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);

            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (onDeleteButtonClickListener != null) {
                        int position = getAbsoluteAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            onDeleteButtonClickListener.onDeleteButtonClick(data.get(position));
                        }
                    }
                }
            });
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_data, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        DataItem item = data.get(position);
        holder.textView.setText(item.getText());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }


}
