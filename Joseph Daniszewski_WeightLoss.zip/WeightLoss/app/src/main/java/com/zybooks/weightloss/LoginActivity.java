package com.zybooks.weightloss;
import static java.security.AccessController.getContext;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen_view);

        // Initialize UI elements
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        // Set click listeners
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle login button click
                loginUser();
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an instance of the fragment
                CreateAccountFragment createAccountFragment = new CreateAccountFragment();

                // Use FragmentManager to replace the current fragment with CreateAccountFragment
                getSupportFragmentManager().beginTransaction()
                        .replace(android.R.id.content, createAccountFragment)
                        .addToBackStack(null) // Optional: Add to the back stack for back navigation
                        .commit();
            }
        });

    }
    private void loginUser() {
        // Retrieve username and password from EditText fields
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        //will eventually check against database
        MainActivity.setisLoggedin(true);
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();

     }


}

